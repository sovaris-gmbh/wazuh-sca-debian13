"""derive_sovaris.py - organisation-specific derivative of cis_debian13_fixed.yml (NOT for publication)."""
import re, sys, yaml, textwrap
FIXED = open('cis_debian13_fixed.yml').read()
# ---------------------------------------------------------------- helpers
def block_span(txt, cid):
    m = re.search(r"^  - id: %d\n.*?(?=^  - id: |\Z)" % cid, txt, re.S | re.M)
    if not m: sys.exit(f"check {cid} not found")
    return m.start(), m.end()

def replace_line(txt, cid, old, new, reason, tag="FIX"):
    """Replace one exact rule line inside a check; keep the original as a comment."""
    s, e = block_span(txt, cid)
    blk = txt[s:e]
    old_full = "      - " + old
    if blk.count(old_full) != 1: sys.exit(f"[{cid}] line not unique/found:\n{old}")
    ind = "      "
    comment = "\n".join(ind + "# " + l for l in textwrap.wrap(f"{tag} ({cid}): {reason}", 110))
    newl = "\n".join(ind + "- " + n for n in ([new] if isinstance(new, str) else new))
    rep = f"{comment}\n{ind}# ORIGINAL: - {old}\n{newl}"
    return txt[:s] + blk.replace(old_full, rep) + txt[e:]

def set_condition(txt, cid, new, reason):
    s, e = block_span(txt, cid)
    blk = txt[s:e]
    m = re.search(r"^    condition: (\w+)$", blk, re.M)
    if not m: sys.exit(f"[{cid}] condition not found")
    old = m.group(1)
    comment = "\n".join("    # " + l for l in textwrap.wrap(f"FIX ({cid}): condition '{old}' -> '{new}': {reason}", 112))
    rep = f"{comment}\n    # ORIGINAL: condition: {old}\n    condition: {new}"
    return txt[:s] + blk.replace(m.group(0), rep, 1) + txt[e:]

def add_rule(txt, cid, new, reason):
    """Append a rule at the end of the rules list of a check."""
    s, e = block_span(txt, cid)
    blk = txt[s:e]
    m = re.search(r"^    rules:\n((?:      .*\n)+)", blk, re.M)
    if not m: sys.exit(f"[{cid}] rules not found")
    ind = "      "
    comment = "\n".join(ind + "# " + l for l in textwrap.wrap(f"FIX ({cid}): {reason}", 110))
    rep = m.group(0) + f"{comment}\n{ind}- {new}\n"
    return txt[:s] + blk.replace(m.group(0), rep, 1) + txt[e:]

def disable_check(txt, cid, reason):
    """Comment out a whole check (org exception)."""
    s, e = block_span(txt, cid)
    blk = txt[s:e]
    body, trail = blk.rstrip("\n"), blk[len(blk.rstrip("\n")):]
    # keep trailing section comments (lines starting with '  # ') outside the disabled block
    lines = body.split("\n")
    while lines and (lines[-1].startswith("  # ") or lines[-1].strip() == ""):
        trail = lines.pop() + "\n" + trail
    head = "\n".join("  # " + l for l in textwrap.wrap(f"ORG-EXCEPTION ({cid}): {reason}", 112))
    rep = head + "\n" + "\n".join("  #" + l for l in lines) + "\n" + trail
    return txt[:s] + rep + txt[e:]

# ---------------------------------------------------------------- 2) sovaris derivative
s = FIXED.replace('  id: "cis_debian13_fixed"\n  file: "cis_debian13_fixed.yml"\n  name: "Center for Internet Security Debian Linux 13 Benchmark (community-fixed)"',
                  '  id: "sovaris_debian13"\n  file: "sovaris_debian13.yml"\n  name: "CIS Debian 13 Benchmark (community-fixed) - sovaris platform baseline"', 1)
s = s.replace("# Based on:\n# Center for Internet Security Debian Linux 12 Benchmark v1.1.0 - 09-26-2024  (sic - upstream note)\n",
              "# Based on:\n# Center for Internet Security Debian Linux 12 Benchmark v1.1.0 - 09-26-2024  (sic - upstream note)\n#\n# SOVARIS DERIVATIVE: identical to cis_debian13_fixed.yml plus organisation-specific exceptions,\n# each commented out with an ORG-EXCEPTION note (decision, reason, compensating control).\n# Do not use this file outside the sovaris platform; use cis_debian13_fixed.yml instead.\n", 1)
EXC = {
 33018: "no separate /home partition: single-partition cloud image by decision (Schritt 14 Stufe 3 declined); data lives in volumes and PBS backups",
 33019: "depends on 33018 (separate /home)", 33020: "depends on 33018 (separate /home)",
 33021: "no separate /var partition: same decision as 33018", 33022: "depends on 33021", 33023: "depends on 33021",
 33043: "no GRUB password: VMs without physical console; PVE console + GRUB rescue (init=/bin/bash) is the documented break-glass path - a password would block recovery",
 33179: "NOPASSWD stays for the automation account `ops`: Semaphore/Ansible become without password; compensating controls: key-only SSH, AllowUsers, sudo.log + auditd (scope, user_emulation)",
 33229: "systemd-journal-remote not used: central logging is journald -> Grafana Alloy -> Loki",
 33231: "systemd-journal-upload not used: see 33229",
 33236: "rsyslog not installed: journald -> Alloy -> Loki; rsyslog would duplicate every line",
 33237: "rsyslog not installed: see 33236", 33238: "journald does not forward to rsyslog: see 33236", 33239: "rsyslog not installed: see 33236",
 33251: "auditd disk_full_action=syslog instead of halt/single: a production VM must not halt because /var/log is full; Loki + Wazuh alert on it; separate log disk planned (Schritt 14b)",
 33252: "auditd space_left_action=syslog: see 33251",
 33284: "AIDE not installed: Wazuh FIM (syscheck) provides file integrity monitoring on every host",
 33285: "AIDE not installed: see 33284",
}
for cid in (33133, 33134, 33136, 33137, 33138, 33140, 33141):
    EXC[cid] = "CIS 4.3.x (nftables front end) not applicable: ufw is the chosen firewall (CIS 4.1)"
for cid in (33143, 33144, 33145, 33146, 33147, 33150, 33151):
    EXC[cid] = "CIS 4.4.x (iptables front end) not applicable: ufw is the chosen firewall (CIS 4.1)"
for cid, reason in EXC.items():
    s = disable_check(s, cid, reason)
open('sovaris_debian13.yml', 'w').write(s)

pol = yaml.safe_load(open('sovaris_debian13.yml'))
print("sovaris_debian13.yml:", len(pol['checks']), "checks (", 207-len(pol['checks']), "org exceptions commented out )")
