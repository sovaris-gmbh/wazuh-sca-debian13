# Wazuh SCA policy for Debian 13 – community-fixed edition

`cis_debian13_fixed.yml` is `ruleset/sca/debian/cis_debian13.yml` from wazuh/wazuh **v4.14.8**
with the rules corrected that no correctly configured Debian 13 system can satisfy. Every change
keeps the upstream line as a comment (`# ORIGINAL: …`) directly above the corrected line, tagged
with the check id and the reason – the file header lists all of them.

* `original.yml` – upstream file, byte-identical (for `diff`)
* `build.py` – produces `cis_debian13_fixed.yml` from `original.yml`; every edit is explicit and
  validated (YAML parses, 207 checks, no unsupported regex construct left)
* `cis_debian13_fixed.yml` – the result

## Deploy
Place the file in the manager's shared group directory and reference it from `agent.conf`,
disabling the stock policy:

```xml
<agent_config>
  <sca>
    <policies>
      <policy enabled="no">cis_debian13.yml</policy>
      <policy>etc/shared/cis_debian13_fixed.yml</policy>
    </policies>
  </sca>
</agent_config>
```

## Site adaptation
CIS 4.x lets you choose one firewall front end – comment out the branches you do not use in a
derived copy (see `policy.id`/`file` metadata; keep ids unique). Organisation-specific exceptions
belong into such a derived file, never into this one.

## Why not a pull request upstream?
It is – this repository is the review-ready intermediate. Related upstream threads:
wazuh/wazuh discussions #37243, issues #39339, #34505.

License: GNU GPL v2, as upstream.
